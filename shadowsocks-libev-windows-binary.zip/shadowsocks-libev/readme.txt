Compiled by cokebar

Original post:
    https://cokebar.info/archives/1988